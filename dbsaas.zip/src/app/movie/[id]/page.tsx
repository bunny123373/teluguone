"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { useParams } from "next/navigation";
import { motion } from "framer-motion";
import { Play, Download, Star, Calendar, Globe, ArrowLeft, Clock } from "lucide-react";
import { IContent } from "@/models/Content";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Button from "@/components/ui/Button";
import Badge from "@/components/ui/Badge";
import ContentCard from "@/components/ContentCard";

export default function MovieDetailsPage() {
  const params = useParams();
  const [movie, setMovie] = useState<IContent | null>(null);
  const [similarMovies, setSimilarMovies] = useState<IContent[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (params.id) {
      fetchMovie();
    }
  }, [params.id]);

  const fetchMovie = async () => {
    setLoading(true);
    try {
      const response = await fetch(`/api/content/${params.id}`);
      const data = await response.json();
      if (data.success) {
        setMovie(data.data);
        fetchSimilarMovies(data.data.language, data.data._id);
      }
    } catch (error) {
      console.error("Error fetching movie:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchSimilarMovies = async (language: string, excludeId: string) => {
    try {
      const response = await fetch(`/api/content?type=movie&language=${language}`);
      const data = await response.json();
      if (data.success) {
        setSimilarMovies(
          data.data
            .filter((m: IContent) => m._id !== excludeId)
            .slice(0, 6)
        );
      }
    } catch (error) {
      console.error("Error fetching similar movies:", error);
    }
  };

  if (loading) {
    return (
      <main className="min-h-screen bg-background">
        <Navbar />
        <div className="py-20 text-center">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
        </div>
      </main>
    );
  }

  if (!movie) {
    return (
      <main className="min-h-screen bg-background">
        <Navbar />
        <div className="py-20 text-center">
          <p className="text-muted text-lg">Movie not found</p>
          <Link href="/" className="text-primary hover:underline mt-4 inline-block">
            Go back home
          </Link>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-background">
      <Navbar />

      {/* Banner Background */}
      <div className="relative h-[400px] md:h-[500px]">
        <Image
          src={movie.banner || movie.poster}
          alt={movie.title}
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/70 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/50 to-transparent" />
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-48 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-8"
        >
          {/* Poster */}
          <div className="md:col-span-1">
            <div className="relative aspect-[2/3] rounded-2xl overflow-hidden shadow-2xl border border-border">
              <Image
                src={movie.poster}
                alt={movie.title}
                fill
                className="object-cover"
              />
            </div>
          </div>

          {/* Details */}
          <div className="md:col-span-2 space-y-6">
            {/* Back Button */}
            <Link
              href="/"
              className="inline-flex items-center gap-2 text-muted hover:text-text transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Home
            </Link>

            {/* Badges */}
            <div className="flex flex-wrap gap-2">
              <Badge variant="primary">Movie</Badge>
              {movie.quality && <Badge variant="accent">{movie.quality}</Badge>}
              {movie.language && <Badge variant="secondary">{movie.language}</Badge>}
              {movie.category && <Badge variant="default">{movie.category}</Badge>}
            </div>

            {/* Title */}
            <h1 className="text-3xl md:text-5xl font-bold text-text">
              {movie.title}
            </h1>

            {/* Meta Info */}
            <div className="flex flex-wrap items-center gap-4 text-sm text-muted">
              {movie.year && (
                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  <span>{movie.year}</span>
                </div>
              )}
              {movie.rating && (
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 text-yellow-500" />
                  <span>{movie.rating}/10</span>
                </div>
              )}
              {movie.language && (
                <div className="flex items-center gap-1">
                  <Globe className="w-4 h-4" />
                  <span>{movie.language}</span>
                </div>
              )}
            </div>

            {/* Description */}
            {movie.description && (
              <p className="text-muted leading-relaxed">{movie.description}</p>
            )}

            {/* Tags */}
            {movie.tags && movie.tags.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {movie.tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-3 py-1 rounded-full bg-card border border-border text-sm text-muted"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex flex-wrap gap-4 pt-4">
              <Link href={`/watch/${movie._id}`}>
                <Button size="lg" className="gap-2">
                  <Play className="w-5 h-5" />
                  Watch Now
                </Button>
              </Link>
              {movie.downloadLink && (
                <a
                  href={movie.downloadLink}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Button variant="outline" size="lg" className="gap-2">
                    <Download className="w-5 h-5" />
                    Download
                  </Button>
                </a>
              )}
            </div>
          </div>
        </motion.div>

        {/* Similar Movies */}
        {similarMovies.length > 0 && (
          <section className="py-12">
            <h2 className="text-2xl font-bold text-text mb-6">Similar Movies</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {similarMovies.map((item, index) => (
                <motion.div
                  key={item._id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <ContentCard content={item} />
                </motion.div>
              ))}
            </div>
          </section>
        )}
      </div>

      <Footer />
    </main>
  );
}
