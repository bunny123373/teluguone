# TeluguDB - Movie Streaming & Download Platform

A modern, full-stack movie streaming and download platform built with Next.js 14+, TypeScript, MongoDB, and Redux Toolkit. Features a Netflix-inspired UI with a unique CineSaaS Dark Neon theme.

![TeluguDB Banner](https://via.placeholder.com/1200x400/070A12/FF2E63?text=TeluguDB)

## Features

### Public Features
- **Home Page**: Browse trending, latest, Telugu, Hindi movies and web series
- **Movie Details**: View movie information with poster, banner, ratings, and descriptions
- **Video Player**: HTML5 video player with custom controls for streaming
- **Series Support**: Multi-season series with episode navigation
- **Search & Filter**: Real-time search and type filtering (All/Movies/Series)
- **Responsive Design**: Fully responsive for mobile, tablet, and desktop
- **SEO Optimized**: Dynamic metadata and OpenGraph tags

### Admin Features
- **Secure Access**: Protected by secret admin key
- **Dashboard**: Overview stats (Total Movies, Series, Episodes, Trending)
- **Upload Movie**: Add movies with poster, banner, watch link, and download link
- **Upload Series**: Add web series with seasons and episodes
- **Manage Content**: Edit or delete existing content
- **Season/Episode Builder**: Interactive UI for managing series episodes

## Tech Stack

- **Framework**: Next.js 14+ (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS
- **Database**: MongoDB Atlas with Mongoose
- **State Management**: Redux Toolkit + React-Redux
- **Animations**: Framer Motion
- **Icons**: Lucide React

## Project Structure

```
telugudb/
├── src/
│   ├── app/                    # Next.js App Router
│   │   ├── api/content/        # API Routes
│   │   ├── admin/              # Admin Dashboard
│   │   ├── movie/[id]/         # Movie Details Page
│   │   ├── watch/[id]/         # Movie Watch Page
│   │   ├── series/[id]/        # Series Details Page
│   │   ├── series/watch/[id]/  # Series Watch Page
│   │   ├── globals.css         # Global Styles
│   │   ├── layout.tsx          # Root Layout
│   │   ├── page.tsx            # Home Page
│   │   └── providers.tsx       # Redux Provider
│   ├── components/
│   │   ├── ui/                 # UI Components (Button, Input, Badge, Modal)
│   │   ├── admin/              # Admin Components
│   │   ├── Navbar.tsx
│   │   ├── HeroBanner.tsx
│   │   ├── ContentCard.tsx
│   │   ├── ContentGrid.tsx
│   │   ├── VideoPlayer.tsx
│   │   ├── EpisodeList.tsx
│   │   └── Footer.tsx
│   ├── redux/
│   │   ├── store.ts
│   │   ├── hooks.ts
│   │   └── slices/
│   │       ├── contentSlice.ts
│   │       └── uiSlice.ts
│   ├── models/
│   │   └── Content.ts          # Mongoose Schema
│   ├── lib/
│   │   ├── mongodb.ts          # MongoDB Connection
│   │   └── utils.ts            # Utility Functions
│   └── utils/
│       ├── constants.ts
│       └── formatDate.ts
├── public/
├── package.json
├── next.config.js
├── tailwind.config.ts
├── tsconfig.json
└── .env.local
```

## Installation

1. **Clone the repository**
```bash
git clone https://github.com/yourusername/telugudb.git
cd telugudb
```

2. **Install dependencies**
```bash
npm install
```

3. **Set up environment variables**
Create a `.env.local` file in the root directory:
```env
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/telugudb?retryWrites=true&w=majority
ADMIN_KEY=your-secret-admin-key
```

4. **Run the development server**
```bash
npm run dev
```

5. **Open in browser**
Navigate to [http://localhost:3000](http://localhost:3000)

## Admin Access

1. Navigate to `/admin`
2. Enter your admin key (set in `.env.local`)
3. Access the dashboard to manage content

## API Routes

### Public Routes
- `GET /api/content` - Get all content (with optional filters)
- `GET /api/content/[id]` - Get single content by ID

### Admin Routes (Require `x-admin-key` header)
- `POST /api/content` - Create new content
- `PUT /api/content/[id]` - Update content
- `DELETE /api/content/[id]` - Delete content

## Database Schema

### Content Model
```typescript
{
  type: "movie" | "series",
  title: string,
  poster: string,
  banner?: string,
  description?: string,
  year?: string,
  language?: string,
  category?: string,
  quality?: string,
  rating?: number,
  tags?: string[],
  watchLink?: string,      // For movies
  downloadLink?: string,   // For movies
  seasons?: [{
    seasonNumber: number,
    episodes: [{
      episodeNumber: number,
      episodeTitle: string,
      watchLink: string,
      downloadLink: string,
      quality?: string
    }]
  }],
  createdAt: Date,
  updatedAt: Date
}
```

## Deployment

### Deploy to Vercel

1. **Push to GitHub**
```bash
git add .
git commit -m "Initial commit"
git push origin main
```

2. **Connect to Vercel**
- Go to [Vercel](https://vercel.com)
- Import your GitHub repository
- Add environment variables (MONGODB_URI, ADMIN_KEY)
- Deploy

3. **Update MongoDB Atlas**
- Add Vercel domain to MongoDB Atlas IP whitelist
- Or allow access from anywhere (0.0.0.0/0) for testing

## Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `MONGODB_URI` | MongoDB Atlas connection string | Yes |
| `ADMIN_KEY` | Secret key for admin access | Yes |

## Customization

### Theme Colors
Edit `tailwind.config.ts` to customize the theme:
```typescript
colors: {
  background: "#070A12",
  card: "#0F172A",
  border: "#1E293B",
  primary: "#FF2E63",    // Neon pink-red
  secondary: "#3A86FF",  // Electric blue
  accent: "#00F5D4",     // Aqua glow
  text: "#E5E7EB",
  muted: "#94A3B8",
}
```

### Categories & Languages
Edit `src/utils/constants.ts` to customize categories and languages.

## License

This project is licensed under the MIT License.

## Support

For support, email support@telugudb.com or join our Discord server.

---

Built with love for movie lovers!
